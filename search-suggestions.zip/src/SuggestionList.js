import React from "react";

export default function SuggestionList({ results }) {
  return (
    <div>
      <ul>
        {results.map((result) => (
          <li>{result}</li>
        ))}
      </ul>
    </div>
  );
}
