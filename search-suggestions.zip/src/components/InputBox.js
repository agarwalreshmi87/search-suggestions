import React from "react";

/* The component to be called with the value of input text box and action to be performed when user input changes */
export default function InputBox({ textValue, onChange }) {
  return (
    <input
      className="inputAutocomplete"
      type="textbox"
      value={textValue}
      onChange={(e) => onChange(e)}
      placeholder="Type your search here"
    />
  );
}
