import React from "react";

/* The component to be called with the suggestion lists and action to be performed when user selects the item */
export default function SuggestionList({ results, onSelectItem }) {
  return (
    <div className="autocomplete-items">
      {results.map((result, index) => (
        <div
          key={index}
          onClick={() => {
            onSelectItem(result);
          }}
        >
          {result}
        </div>
      ))}
    </div>
  );
}
