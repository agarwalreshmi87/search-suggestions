import "./styles.css";
import React, { useState, useEffect } from "react";
import InputBox from "./components/InputBox";
import SuggestionList from "./components/SuggestionList";
import getSuggestion from "./api/getSuggestion";

export default function App() {
  /* const space key used to determine the current typed word*/
  const SPACE_KEY = 32;

  /* state to set the user input in search textbox*/
  const [inputText, setInputText] = useState("");

  /* state to set the current input to getSuggestion API */
  const [suggestionText, setSuggestionText] = useState("");

  /* state to set suggestion list as per user typed word */
  const [results, setResults] = useState([]);

  /* state to show if error messages, from API */
  const [error, setErrorMessage] = useState("");

  /* Function to handle changes due to user input */
  function handleInputChange(e) {
    setInputText(e.target.value);
    if (e.target.value !== "") {
      let allChars = e.target.value.split(" ");
      /* split the user input on space and take the latest word getting typed*/
      let suggestionText = allChars[allChars.length - 1];

      if (e.keyCode === SPACE_KEY) {
        setSuggestionText(
          ""
        ); /* if "space" entered, we assume a new word is getting typed, hence will set input to suggestion API as empty*/
      }

      /* if backspace pressed and the char immediate before is "space", we show result from previous word*/
      if (suggestionText === "") {
        suggestionText = allChars[allChars.length - 2];
      }

      setSuggestionText(suggestionText);
    } else {
      /* if user deletes all typed characters in search box, suggestion list should be set to empty */
      setResults([]);
    }
  }

  /* depending upon the business logic this function can be modified to populate the inputbox on select item from suggestion list*/
  function onSelect(item) {
    setInputText(item);
    setResults([]);
  }

  /* Function to fetch results from getSuggestionAPI */
  async function callGetSuggestionAPI(text) {
    try {
      let response = await getSuggestion(text);
      setResults(response);
    } catch (e) {
      setErrorMessage(e);
    }
  }

  /* call API only when user input changes */
  useEffect(() => {
    if (suggestionText && suggestionText.length > 0) {
      var timer = setTimeout(() => {
        callGetSuggestionAPI(suggestionText);
      }, 200); /* API to wait for 200ms before firing each time */
      return () => {
        clearTimeout(timer); /* clear the previous timer on next fetch */
      };
    }
  }, [suggestionText]);

  return (
    <div className="App">
      {error ? <div className="errortext">{error}</div> : ""}
      <div className="autocomplete">
        <InputBox textValue={inputText} onChange={handleInputChange} />
        <SuggestionList results={results} onSelectItem={onSelect} />
      </div>
    </div>
  );
}
